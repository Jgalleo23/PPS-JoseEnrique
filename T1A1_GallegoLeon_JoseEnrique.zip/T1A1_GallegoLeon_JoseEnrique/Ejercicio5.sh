#!/bin/bash
# Este script maneja parámetros y retorna códigos de salida
if [ $# -eq 0 ]; then
    echo "No has introducido ningún parámetro"
    exit 1
else
    echo "Has introducido $# parámetros"
    echo "Los parámetros son: $@"
    exit 0
fi
