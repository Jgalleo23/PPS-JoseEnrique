#!/bin/bash
# Este script maneja parámetros
if [ $# -eq 0 ]; then
    echo "No has introducido ningún parámetro"
else
    echo "Has introducido $# parámetros"
    echo "Los parámetros son: $@"
fi
