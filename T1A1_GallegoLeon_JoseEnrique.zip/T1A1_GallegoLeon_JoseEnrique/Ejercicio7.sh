#!/bin/bash
# Este script verifica si el parámetro es un archivo o un directorio
if [ -e "$1" ]; then
    if [ -f "$1" ]; then
        echo "$1 es un archivo."
    elif [ -d "$1" ]; then
        echo "$1 es un directorio."
    fi
else
    echo "El archivo o directorio no existe."
fi
