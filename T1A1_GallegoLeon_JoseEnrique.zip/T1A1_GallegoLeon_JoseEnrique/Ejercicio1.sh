#!/bin/bash
# Este script muestra su propio nombre
echo "El nombre del script es: $0"
