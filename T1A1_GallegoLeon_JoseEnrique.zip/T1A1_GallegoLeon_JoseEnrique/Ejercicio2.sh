#!/bin/bash
# Este script muestra el contenido de un archivo y su exit code
if [ -f "$2" ]; then
    cat "$2"
    echo "Exit code: $?"
else
    echo "El archivo no existe o no tienes permiso de lectura."
    echo "Exit code: $?"
fi
