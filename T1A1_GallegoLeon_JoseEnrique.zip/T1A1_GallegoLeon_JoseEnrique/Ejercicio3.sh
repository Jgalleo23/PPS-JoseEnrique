#!/bin/bash
# Este script crea un directorio y copia un archivo dentro
mkdir -p "$1"
cp "$2" "$1"
