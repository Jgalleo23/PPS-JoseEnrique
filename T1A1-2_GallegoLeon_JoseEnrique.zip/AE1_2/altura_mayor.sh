#!/bin/bash
# Solicitamos al usuario las alturas de tres personas
echo "Introduce la altura en cm de la primera persona:"
read altura1
echo "Introduce la altura en cm de la segunda persona:"
read altura2
echo "Introduce la altura en cm de la tercera persona:"
read altura3

# Comprobamos que todos los valores ingresados sean números válidos
if ! [[ "$altura1" =~ ^[0-9]+$ && "$altura2" =~ ^[0-9]+$ && "$altura3" =~ ^[0-9]+$ ]]; then
  echo "Por favor, introduce valores válidos para las alturas."
  exit 1
fi

# Determinamos cuál es la altura mayor
mayor=$(( altura1 > altura2 ? (altura1 > altura3 ? altura1 : altura3) : (altura2 > altura3 ? altura2 : altura3) ))

# Convertimos la altura mayor a metros y la mostramos
echo "La altura mayor es $((mayor / 100)).$((mayor % 100)) metros."
