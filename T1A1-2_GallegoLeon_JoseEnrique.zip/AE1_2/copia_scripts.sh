#!/bin/bash

# Pedimos al usuario que introduzca el directorio
echo "Introduce el directorio donde buscar archivos .sh:"
read directorio

# Verificamos si el directorio es válido
if [[ ! -d $directorio ]]; then
  echo "Introduce un directorio válido."
  exit 1
fi

# Obtenemos la fecha actual en el formato requerido
fecha=$(date +%d%m%Y)
archivo="copia_scripts_$fecha.tar"

# Encontramos los archivos .sh y los empaquetamos
find "$directorio" -name "*.sh" | tar -cvf "$archivo" -T -

# Informamos al usuario del nombre del archivo creado
echo "Archivos .sh copiados en $archivo."

