#!/bin/bash
# Obtenemos el nombre del mes actual
mes=$(date +%B)

# Calculamos el número de días del mes
dias=$(date +%d -d "$(date +%Y%m01) +1 month -1 day")

# Mostramos el mes actual y el número de días
echo "Estamos en $mes, un mes con $dias días."
