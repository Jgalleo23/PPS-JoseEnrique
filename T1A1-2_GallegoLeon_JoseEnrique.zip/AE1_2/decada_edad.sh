#!/bin/bash

# Función para pedir la edad al usuario
pedir_edad() {
    echo "Introduce tu edad (entre 15 y 60 años):"
    read edad
}

# Función para validar la edad
validar_edad() {
    if ! [[ "$edad" =~ ^[0-9]+$ ]] || (( edad < 15 || edad > 60 )); then
        echo "Por favor, introduce una edad válida entre 15 y 60 años."
        return 1  # Devuelve un código de error
    fi
    return 0  # Devuelve cero si la edad es válida
}

# Bucle para solicitar la edad hasta que sea válida
while true; do
    pedir_edad
    if validar_edad; then
        break  # Sale del bucle si la edad es válida
    fi
done

# Obtener el año actual y calcular el año de nacimiento
ano_actual=$(date +%Y)
ano_nacimiento=$(( ano_actual - edad ))

# Calcular la década correspondiente al año de nacimiento
decada=$(( ano_nacimiento / 10 * 10 ))

# Mostrar el año de nacimiento y su década
echo "Si naciste en $ano_nacimiento, naciste en la década de $decada."

