#!/bin/bash
# Pedimos al usuario su año de nacimiento
echo "Introduce tu año de nacimiento (4 cifras):"
read ano

# Verificamos que el año sea un número de 4 dígitos
if ! [[ "$ano" =~ ^[0-9]{4}$ ]]; then
  echo "Por favor, introduce un año válido de 4 cifras."
  exit 1
fi

# Calculamos el animal del horóscopo chino usando el resto de la división entre 12
animal=$(( ano % 12 ))

# Seleccionamos el animal correspondiente según el resto obtenido
case $animal in
  0) echo "Tu animal es la rata." ;;
  1) echo "Tu animal es el buey." ;;
  2) echo "Tu animal es el tigre." ;;
  3) echo "Tu animal es el conejo." ;;
  4) echo "Tu animal es el dragón." ;;
  5) echo "Tu animal es la serpiente." ;;
  6) echo "Tu animal es el caballo." ;;
  7) echo "Tu animal es la cabra." ;;
  8) echo "Tu animal es el mono." ;;
  9) echo "Tu animal es el gallo." ;;
  10) echo "Tu animal es el perro." ;;
  11) echo "Tu animal es el cerdo." ;;
esac
