#!/bin/bash
# Pedimos al usuario que introduzca un número
echo "Introduce un número:"
read numero

# Verificamos si el valor ingresado es un número
if ! [[ "$numero" =~ ^[0-9]+$ ]]; then
  echo "Por favor, introduce un número válido."
  exit 1
fi

# Comprobamos si el número es múltiplo de 10
if (( numero % 10 == 0 )); then
  echo "$numero es múltiplo de 10."
else
  echo "$numero no es múltiplo de 10."
fi
