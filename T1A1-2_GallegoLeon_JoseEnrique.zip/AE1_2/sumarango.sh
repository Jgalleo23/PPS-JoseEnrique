#!/bin/bash
# Solicitamos dos números al usuario para definir el rango
echo "Introduce el primer número:"
read num1
echo "Introduce el segundo número:"
read num2

# Verificamos que ambos valores sean números válidos
if ! [[ "$num1" =~ ^[0-9]+$ && "$num2" =~ ^[0-9]+$ ]]; then
  echo "Por favor, introduce números válidos."
  exit 1
fi

# Comprobamos cuál número es menor y, si es necesario, invertimos el orden
if (( num1 > num2 )); then
  temp=$num1
  num1=$num2
  num2=$temp
fi

# Calculamos la suma de los números en el rango
suma=0
for (( i = num1; i <= num2; i++ )); do
  suma=$(( suma + i ))
done

# Mostramos el resultado
echo "La suma del rango es $suma."
