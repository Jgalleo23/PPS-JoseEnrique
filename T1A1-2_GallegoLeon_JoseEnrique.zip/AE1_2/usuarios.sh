#!/bin/bash
# Definimos un archivo para almacenar errores
log_file="error_log.txt"

# Bucle que permite consultar información de varios usuarios
while true; do
  echo "Introduce el nombre de usuario:"
  read usuario

  # Verificamos si el usuario existe en el sistema
  if ! id "$usuario" &> /dev/null; then
    echo "El usuario no existe."
    echo "Error: El usuario $usuario no existe." >> $log_file
  else
    # Obtenemos UID, GID y directorio de trabajo
    uid=$(id -u "$usuario")
    gid=$(id -g "$usuario")
    home=$(eval echo ~$usuario)
    echo "Nombre de usuario: $usuario"
    echo "UID: $uid"
    echo "GID: $gid"
    echo "Directorio de trabajo: $home"
  fi

  # Preguntamos si se desea consultar otro usuario
  echo "¿Quieres consultar otro usuario? (s/n):"
  read respuesta
  [[ $respuesta != "s" ]] && break
done
