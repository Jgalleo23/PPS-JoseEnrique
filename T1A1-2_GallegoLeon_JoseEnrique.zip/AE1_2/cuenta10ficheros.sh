#!/bin/bash

# Solicita al usuario que introduzca la ruta de un directorio
echo "Introduce la ruta de un directorio:"
read directorio

# Comprueba si el directorio ingresado es válido
if [[ ! -d $directorio ]]; then
  echo "La ruta proporcionada no es un directorio válido."
  exit
fi

# Cuenta solo los archivos en el directorio (excluyendo subdirectorios)
num_archivos=$(find "$directorio" -maxdepth 1 -type f | wc -l)

# Muestra si hay más de 10 archivos o no
if (( num_archivos > 10 )); then
  echo "El directorio tiene más de 10 archivos."
else
  echo "El directorio tiene 10 archivos o menos."
fi

